import java.util.Scanner;
//the data of Employee cannot be accessed directly
public class MainClass {
public static void main(String[] args) {
	Scanner input = new Scanner(System.in);
	Employee emp1 = new Employee();
	//the values can be set only via setter method
	System.out.println("Enter employee id ");
	emp1.setEmpid(input.nextInt());
	System.out.println("Enter employee name ");
	emp1.setEmpname(input.next());
	System.out.println("Enter employee designation: Developer,Manager,Architect ");
	emp1.setEmpDesignation(input.next());
	input.close();
	//These can be accessed only via 
	System.out.println("The employee details are:");
	System.out.println("Employee id: " +emp1.getEmpid());
	System.out.println("Employee name: " +emp1.getEmpname());
	System.out.println("Employee designation: " +emp1.getEmpDesignation());	
	System.out.println("Employee salary : " +emp1.getEmpSalary(emp1.getEmpDesignation()));
	
}
}
