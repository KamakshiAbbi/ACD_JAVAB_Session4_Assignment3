//Session4_Assignment3 : 8.5.2016
//Author: Kamakshi Abbi
public class Employee {
	//private employee details
	private int empid;
	private String empname;
	private String empDesignation;
	private double empSalary;
	
	//accessible only via employee details
	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpname() {
		return empname;
	}

	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public double getEmpSalary(String designation) {
		if(designation.equals("Developer")){
			this.empSalary = 40000.0;
		}
		else if(designation.equals("Manager")){
			this.empSalary = 100000.0;
		}
		else if(designation.equals("Architect")){
			this.empSalary = 80000.0;
			
		}
		return empSalary;
	}

	

}
